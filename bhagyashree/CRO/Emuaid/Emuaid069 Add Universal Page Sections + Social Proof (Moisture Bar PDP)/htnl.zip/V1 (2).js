<div class="custProdutsDiscreption">
    <div class="custPaymentImg">
        <img src="https://growth-hit.s3.us-west-2.amazonaws.com/emuaid/payment-logos.jpg" class="custDeasktop">
        <img src="https://growth-hit.s3.us-west-2.amazonaws.com/emuaid/payment-logos-mobile.jpg" class="custmobile"> 
    </div>
    <div class="custAcordianList">
        <div class="custAcordianBlock">
        <h2>Why EMUAID® Works</h2>
        <div class="custAcordianContent">
            <p>EMUAID® Therapeutic Moisture Bar is a perfect complement to EMUAID® First Aid Ointment for pain and discomfort relief from dermatitis, eczema, psoriasis, and rosacea. The natural soap bar contains nature’s most effective anti-bacterial and anti-fungal essential oils that deliver intense hydration and stimulate natural skin regeneration. For other more severe skin conditions, we recommend EMUAIDMAX®, which features more potent healing ingredients that can help manage the respective conditions more effectively. Talk to us if you are still unsure which EMUAID® product to get for your skin.</p>
        </div>
        </div>

        <div class="custAcordianBlock">
        <h2>Ingredients</h2>
        <div class="custAcordianContent">
            <p>EMUAID® Therapeutic Moisture Bar is a perfect complement to EMUAID® First Aid Ointment for pain and discomfort relief from dermatitis, eczema, psoriasis, and rosacea. The natural soap bar contains nature’s most effective anti-bacterial and anti-fungal essential oils that deliver intense hydration and stimulate natural skin regeneration. For other more severe skin conditions, we recommend EMUAIDMAX®, which features more potent healing ingredients that can help manage the respective conditions more effectively. Talk to us if you are still unsure which EMUAID® product to get for your skin.</p>
        </div>
        </div>

        <div class="custAcordianBlock">
        <h2>30 Day Money-Back Guarantee</h2>
        <div class="custAcordianContent">
            <p>EMUAID® Therapeutic Moisture Bar is a perfect complement to EMUAID® First Aid Ointment for pain and discomfort relief from dermatitis, eczema, psoriasis, and rosacea. The natural soap bar contains nature’s most effective anti-bacterial and anti-fungal essential oils that deliver intense hydration and stimulate natural skin regeneration. For other more severe skin conditions, we recommend EMUAIDMAX®, which features more potent healing ingredients that can help manage the respective conditions more effectively. Talk to us if you are still unsure which EMUAID® product to get for your skin.</p>
        </div>
        </div>
        <div class="custAcordianBlock">
        <h2>How To Use</h2>
        <div class="custAcordianContent">
            <p>EMUAID® Therapeutic Moisture Bar is a perfect complement to EMUAID® First Aid Ointment for pain and discomfort relief from dermatitis, eczema, psoriasis, and rosacea. The natural soap bar contains nature’s most effective anti-bacterial and anti-fungal essential oils that deliver intense hydration and stimulate natural skin regeneration. For other more severe skin conditions, we recommend EMUAIDMAX®, which features more potent healing ingredients that can help manage the respective conditions more effectively. Talk to us if you are still unsure which EMUAID® product to get for your skin.</p>
        </div>
        </div>
    </div>
</div>  