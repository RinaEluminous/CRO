var waitForjQuery = setInterval(function() {
	window.MirrorMate012String1 = ''+
'      <div class="custirrorMateBanner">'+ 
'          <div class="custBannerFullBG">'+ 
'              <div class="container">'+ 
'                  <div class="custLeftBannerContent">'+ 
'                      <ul>'+ 
'                          <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/no-tools-required.svg"><span>No tools required</span></li>'+ 
'                          <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/warranty.svg"><span>5-year warranty</span></li>'+ 
'                          <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/crafted-us.svg"><span>Crafted in the U.S.</span></li>'+ 
'                      </ul>'+ 
'                      <div class="custReviewContent"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg"><span class="custStarReviewsContent">Over 4,716 5-star reviews</span></div>'+ 
'                      <h3>Frame Your Bare Mirror</h3>'+ 
'                      <p>Add a beautiful finish to your existing mirror with an easy-install frame kit.</p>'+ 
'                      <div class="customButtonGroup"><a href="https://www.mirrormate.com/collections/all-frames" class="customBlueButton">SHOP FRAME KITS</a><a href="https://www.mirrormate.com/collections/samples" class="customBlueButton">SHOP SAMPLES</a></div>'+ 
'                  </div>'+ 
'                  <div class="custRightBannerImg"><div class="custHowItWorksVideoPopup"><video loop="true" autoplay="autoplay" id="custHowItWorkVideo" muted="" playsinline=""><source src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/backsplash_video.mp4" type="video/mp4"></video><button type="button" id="custPlayButton"></button></div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'              </div>'+ 
'          </div>'+ 
'          <div class="container">'+ 
'              <div class="row">'+ 
'                  <div class="custAsSeenLogosBlock">'+ 
'                      <ul>'+ 
'                          <li><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/3-Better_Homes.jpg?v=1632854398"></li>'+ 
'                          <li><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/4-House_Beautiful.jpg?v=1632854398"></li>'+ 
'                          <li><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/5-This_Old_House.jpg?v=1632854398"></li>'+ 
'                          <li><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/2-HGTV.jpg?v=1632854398"></li>'+ 
'                          <li><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/1-Today.jpg?v=1632854398"></li>'+ 
'                      </ul>'+ 
'                  </div>'+ 
'                  <div class="custWorksOnAnyMirror">'+ 
'                      <ul>'+ 
'                          <li>'+ 
'                              <h2>Works On Any Mirror!</h2>'+ 
'                          </li>'+ 
'                          <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/backsplash_wall.png" class="custDImage"> <img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/backsplash_wall_mob.png" class="custMImage"><a href="https://www.mirrormate.com/pages/faq"><span><img src="https://cdn.shopify.com/s/files/1/0350/5894/1996/files/Green_Check_Mark_copy.png?v=1615206046"/></span>Mirror against backsplash or wall</a></li>'+ 
'                          <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/mirro_with_clip.png" class="custDImage"> <img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/mirro_with_clip_mob.png" class="custMImage"><a href="https://www.mirrormate.com/pages/faq"><span><img src="https://cdn.shopify.com/s/files/1/0350/5894/1996/files/Green_Check_Mark_copy.png?v=1615206046"/></span>Mirror with clips</a></li>'+ 
'                      </ul>'+ 
'                  </div>'+ 
'              </div>'+ 
'          </div>'+ 
'      </div>'+ 
'      <div class="custHowItsWorkVideoBlock custCommonHeading">'+ 
'          <div class="container">'+ 
'              <div class="row">'+ 
'                  <div class="col-md-6">'+ 
'                      <div><div class="custRightBannerImg"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/mob_hero_section_018.jpg">'+ 
'                      <div class="custBannerReviewQuotes"><span>"Completely transformed our bathroom, was super easy to install!"<strong>─ KRISTY C.</strong></span>'+ 
'                          <ul>'+ 
'                              <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg"></li>'+ 
'                              <li>─ KRISTY C.<small> Verified Buyer</small></li>'+ 
'                          </ul>'+ 
'                      </div>'+ 
'                  </div>'+
'                      </div>'+ 
'                  </div>'+ 
'                  <div class="col-md-6"><small>Designed to be easy</small>'+ 
'                      <h2>Measure Your Existing, Wall-mounted Mirror & We\'ll Make A Frame To Fit.</h2>'+ 
'                      <p>It\'ll adhere right to your mirror, so no extra room is needed around it. A recess in the back covers clips & metal strips. It\'s a mirror frame kit! Assembles & installs in minutes. Easy!</p>'+ 
'                      <ul>'+ 
'                          <li>Measure mirror & order kit</li>'+ 
'                          <li>Assemble custom frame & press to mirror</li>'+ 
'                          <li>Love your updated bath!</li>'+ 
'                      </ul>'+ 
'                      <div class="customButtonGroup"><a href="https://www.mirrormate.com/collections/all-frames" class="customBlueButton">SHOP FRAME KITS</a><a href="https://www.mirrormate.com/pages/how-it-works" class="customBlueButton">SEE ALL STEPS <img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/np_arrow-right.svg"></a></div>'+ 
'                  </div>'+ 
'              </div>'+ 
'          </div>'+ 
'      </div>'+ 
'      <div class="custGuaranteeWrapperBlock">'+ 
'          <div class="container custWhiteBg">'+ 
'              <div class="custGuaranteeTitle"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/guarantee.svg">No Worries Guarantee</div>'+ 
'              <ul>'+ 
'                  <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/np_fit.svg"><span>It fits or we replace it.</span></li>'+ 
'                  <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/np_customer-service.svg"><span>The best customer service.</span></li>'+ 
'                  <li><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/np_warranty.svg"><span>5-year warranty</span></li>'+ 
'              </ul>'+ 
'          </div>'+ 
'          <div class="custFramesSoldBlock custCommonHeading">'+ 
'              <h2>Over 450,000 Frames Sold</h2>'+ 
'              <div class="custClientReviewSlider">'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Beautiful frame</h5>'+ 
'                              <p>Frame fit perfectly and was the added touch my bathroom needed</p>'+ 
'                              <div class="custReviewClientInfo">Linda W.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Mirror Mate</h5>'+ 
'                              <p>Absolutely gorgeous</p>'+ 
'                              <div class="custReviewClientInfo">Linda R.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Love!</h5>'+ 
'                              <p>Love them so much that I ordered again for master bath! Easy to do.</p>'+ 
'                              <div class="custReviewClientInfo">Theresa H<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Very pleased with the appearance</h5>'+ 
'                              <p>Very pleased with the appearance and quality of the mirror frame. Install was not "quite" as easy as it appears in the video, but not terribly difficult.</p>'+ 
'                              <div class="custReviewClientInfo">Andrea P.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Nice Frame</h5>'+ 
'                              <p>Nice frame. Improves the appearance and gives a nice finish to guess bathroom. Wife loves it!!</p>'+ 
'                              <div class="custReviewClientInfo">Gary N.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Exactly what we wanted! Easy</h5>'+ 
'                              <p>Exactly what we wanted! Easy install and excellent result!</p>'+ 
'                              <div class="custReviewClientInfo">James S.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Absolutely love my frames. Will</h5>'+ 
'                              <p>Absolutely love my frames. Will be ordering 2 more for my other bathrooms.</p>'+ 
'                              <div class="custReviewClientInfo">Vivian J.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Great frames</h5>'+ 
'                              <p>Everything was great! Not too expensive. It came pretty fast and was easy to install.</p>'+ 
'                              <div class="custReviewClientInfo">Teresa D.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Fantastic value.</h5>'+ 
'                              <p>Purchased two frames which arrived in perfect condition and were easily installed.</p>'+ 
'                              <div class="custReviewClientInfo">Michael K.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Bathroom Mirror Frame</h5>'+ 
'                              <p>We are Very pleased with the mirror frame! Great quality, very easy to install and it looks awesome!</p>'+ 
'                              <div class="custReviewClientInfo">Kent J.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Finishing touch to a bathroom and makeup area.</h5>'+ 
'                              <p>Great!!! Everything is perfect!! Easy to put together, easy too install. Looks amazing!</p>'+ 
'                              <div class="custReviewClientInfo">Mariellen H.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Wow Factor!</h5>'+ 
'                              <p>Ours eyes popped as we put it up and saw the difference right away! Love it and now ordering for another mirror!</p>'+ 
'                              <div class="custReviewClientInfo">Leticia H.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Simple to measure, simple to</h5>'+ 
'                              <p>Simple to measure, simple to hang and looks great!</p>'+ 
'                              <div class="custReviewClientInfo">Ashley C.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>I highly recommended mirrormate!</h5>'+ 
'                              <p>I love my mirrormate frame! It made my bathroom remodel complete!</p>'+ 
'                              <div class="custReviewClientInfo">Ashley C.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Fabulous transformation</h5>'+ 
'                              <p>Mirror Mate frame transformed a large builder grade mirror into a custom piece. Great install instructions, VERY pleased!</p>'+ 
'                              <div class="custReviewClientInfo">Paula P.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Easy installation, great selection</h5>'+ 
'                              <p>Easy installation, great selection and in love with the option we chose. We got a total of 4</p>'+ 
'                              <div class="custReviewClientInfo">Betty M.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Wow!!! What a big difference</h5>'+ 
'                              <p>Wow!!! What a big difference the frame makes in our new master bath! It is so beautiful! Very easy to put together and hang.</p>'+ 
'                              <div class="custReviewClientInfo">Kathleen B.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Makes an old mirror brand new again</h5>'+ 
'                              <p>So easy to assemble and install! Complete transformation without replacing the whole mirror!! Before and after photos attached</p>'+ 
'                              <div class="custReviewClientInfo">Joy G.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>MirrorMate Rocks!</h5>'+ 
'                              <p>Effective customer service, easy ordering process; Quality product. Fast shipping!</p>'+ 
'                              <div class="custReviewClientInfo">Alton W.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'                  <div>'+ 
'                      <div class="custReviewWrapper">'+ 
'                          <div class="custMegaReview"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/rating-stars.svg">'+ 
'                              <h5>Perfect Accessory</h5>'+ 
'                              <p>I\'m very pleased with the addition of the frame to my guest bath. It added the perfect detail.</p>'+ 
'                              <div class="custReviewClientInfo">Alton W.<small>Verified Buyer</small></div>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'              </div>'+ 
'          </div>'+ 
'      </div>';
window.MirrorMate012String2 = ''+ 
'      <div class="custMostPopulerColor custCommonHeading">'+ 
'          <h2>Shop Our Most Popular Colors</h2>'+ 
'          <p>Custom-made frame kits guaranteed to fit any mirror.</p>'+ 
'          <div class="custSlickColorSlider">'+ 
'              <div class="custSlickSliderWrapper">'+ 
'                  <div class="custMostPopulerColorSlider">'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/wood-tones"><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/WoodTones_Frames_Assembled_Simpler.jpg?v=1651500746">'+ 
'                                  <h5>Shop Wood Tones</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/white"><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/files/White_d24c015a-f598-4b43-a718-8f07edc3b3472.jpg?v=1647972205">'+ 
'                                  <h5>Shop White</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/silver-grey"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/silver-home3.png">'+ 
'                                  <h5>Shop Silver/grey</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/black"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/black-home.png">'+ 
'                                  <h5>Shop Black</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/bronze"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/Bronze_Assembled_Simpler.png">'+ 
'                                  <h5>Shop Bronze</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/metallic"><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/collections/Metallic_Group-tmp_medium.jpg?v=1635882856">'+ 
'                                  <h5>Shop Metallic</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/cherry-red"><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/collections/corner-0004_medium.jpg?v=1581190171">'+ 
'                                  <h5>Shop Cherry/Red</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/gold-champagne"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/GoldFrames_Assembled_Simpler.png">'+ 
'                                  <h5>Shop Gold/Champagne</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                      <div class="custColorSlide">'+ 
'                          <div class="custColorFrameBoxWrapper">'+ 
'                              <a href="https://www.mirrormate.com/collections/paintable"><img src="https://cdn.shopify.com/s/files/1/0090/5183/2386/collections/04A612-Paintable-Group_medium.jpg?v=1628519281">'+ 
'                                  <h5>Shop Paintable</h5>'+ 
'                              </a>'+ 
'                          </div>'+ 
'                      </div>'+ 
'                  </div>'+ 
'              </div><a href="https://www.mirrormate.com/collections/all-frames" class="customBlueButton">SHOP POPULAR FRAMES</a></div>'+ 
'      </div>'+ 
'      <div class="custSeeForYourself custCommonHeading">'+ 
'          <div class="custcol6"><img src="https://growth-hit.s3.us-west-2.amazonaws.com/mirrormate/mirror_frame_block.png"></div>'+ 
'          <div class="custcol6">'+ 
'              <h2>See For Yourself</h2>'+ 
'              <p>Grab your samples so you can see what frames styles work best in your space</p><a href="https://www.mirrormate.com/collections/samples" class="customBlueButton">ORDER $2 SAMPLES</a></div>'+ 
'      </div>'+ 
'      <div class="custRealCustomersSection custCommonHeading">'+ 
'          <h2>Real Customers Make MirrorMate Look Easy</h2>'+ 
'          <div class="custMainVideoBlock">'+ 
'              <div>'+ 
'                  <div class="custVideoBlock"><iframe loading="lazy" src="https://fast.wistia.net/embed/iframe/lmnkhocyr7" title="CherokeeBarnwoodbyBrittanysHomeSweetHome Video" allow="autoplay; fullscreen" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed"'+ 
'                          name="wistia_embed" msallowfullscreen="" width="640" height="640"></iframe></div>'+ 
'              </div>'+ 
'              <div>'+ 
'                  <div class="custVideoBlock"><iframe loading="lazy" src="https://fast.wistia.net/embed/iframe/0iaipqm5ea" title="CherokeeBarnwoodbyDanielleNicoleHome Video" allow="autoplay; fullscreen" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed"'+ 
'                          msallowfullscreen="" width="640" height="640"></iframe></div>'+ 
'              </div>'+ 
'              <div>'+ 
'                  <div class="custVideoBlock"><iframe loading="lazy" src="https://fast.wistia.net/embed/iframe/jbbln3e9yo" title="CherokeeFarmhousebyLifestylewithKara Video" allow="autoplay; fullscreen" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed"'+ 
'                          msallowfullscreen="" width="640" height="640"></iframe></div>'+ 
'              </div>'+ 
'          </div>'+ 
'      </div>'+ 
'      <div class="custFAQBlock">'+ 
'          <div class="custFAQwrapper">'+ 
'              <h2>Frequently Asked Questions</h2><label class="custAccordion"><input type="checkbox" name="checkbox-accordion" checked="checked"><div class="custAccordionHeader">Can I order samples?</div><div class="custAccordionContent"><p>We encourage you to order samples to see how the frame looks in your bathroom. Samples can be ordered <strong><a href="/collections/samples" class="a-1" title="Here">here</a></strong>.</p></div></label>'+ 
'              <label'+ 
'                  class="custAccordion"><input type="checkbox" name="checkbox-accordion">'+ 
'                  <div class="custAccordionHeader">How does the product work?</div>'+ 
'                  <div class="custAccordionContent">'+ 
'                      <p>The frame attaches directly to the existing, wall-mounted mirror so you don\'t need space around it for the frame. It is also why it works even if your mirror sits on a backsplash or runs into a wall. The frame tapes onto the glass'+ 
'                          with professional grade, double-side 3M tape - guaranteed to last in the bath. If your mirror is attached with clips, no worries! There is a recess in the back of the frame that allows it to fit over the clips. No other frame or'+ 
'                          store-bought trim has this!</p>'+ 
'                  </div>'+ 
'                  </label><label class="custAccordion"><input type="checkbox" name="checkbox-accordion"><div class="custAccordionHeader">How does the frame attach to the mirror?</div><div class="custAccordionContent"><p>The frame is pre-taped with professional-grade 3M tape and guaranteed to last in the bath.</p></div></label>'+ 
'                  <label'+ 
'                      class="custAccordion"><input type="checkbox" name="checkbox-accordion">'+ 
'                      <div class="custAccordionHeader">What is the frame made of?</div>'+ 
'                      <div class="custAccordionContent">'+ 
'                          <p>The vast majority of our frames are made of MDF (Medium Density Fiberboard), an environmentally-responsible, strong, non-warping wood-base. They are then finished with a moisture-impervious decorative wrap and seal. There are a'+ 
'                              few select styles with a base composite of wood. Each product page provides the exact base composite of that style.</p>'+ 
'                      </div>'+ 
'                      </label><label class="custAccordion"><input type="checkbox" name="checkbox-accordion"><div class="custAccordionHeader">Why should I buy a MirrorMate frame instead of a complete framed mirror?</div><div class="custAccordionContent"><p>MirrorMate frames are less expensive than most new framed mirrors and they don\'t require that you remove your existing mirror. This is especially good news if your existing mirrors are glued to the wall, since removing them may damage the wall, and if they break, may cause injury. The additional time and cost of repairing the wall, plus disposal of mirrors into a landfill make MirrorMate frames even more cost-effective. MirrorMate frames are easy to install, requiring no special tools or skills. They work with any rectangular-shaped mirror and are available in a variety of styles to fit any decor.</p></div></label>'+ 
'                      <label'+ 
'                          class="custAccordion"><input type="checkbox" name="checkbox-accordion">'+ 
'                          <div class="custAccordionHeader">Will I see the mirror edge under the frame from the side?</div>'+ 
'                          <div class="custAccordionContent">'+ 
'                              <p>Where there is space we extend the frame beyond the mirror up to 5/8 inch - to create the illusion that the raw edge of the mirror is covered. If your mirror has zero clearance on a side then we do not extend the frame on that'+ 
'                                  side and the frame will be flush with the edge of the mirror. Please note - our frames DO NOT wrap around the edge of the mirror.</p>'+ 
'                          </div>'+ 
'                          </label><label class="custAccordion"><input type="checkbox" name="checkbox-accordion"><div class="custAccordionHeader">Do you sell mirror too?</div><div class="custAccordionContent"><p>No. Our frames are for pre-existing, wall-mounted mirrors.</p></div></label>'+ 
'                          <label'+ 
'                              class="custAccordion"><input type="checkbox" name="checkbox-accordion">'+ 
'                              <div class="custAccordionHeader">Do you sell frames for oval mirrors?</div>'+ 
'                              <div class="custAccordionContent">'+ 
'                                  <p>No, just for square and rectangular mirrors.</p>'+ 
'                              </div>'+ 
'                              </label>'+ 
'          </div>'+ 
'      </div>';
    if (typeof jQuery != 'undefined' && window.MirrorMate012String1 && window.MirrorMate012String2) {
		var flag = 0;
	
		//function to add custom HTML to the Home Page
		if(jQuery('.template-index').length > 0){
			addCustHTMLForHpEducationFirst();
		}
		
		//If user is redirected from Home page to FAQ page, then scroll it to second FAQ section
		if(jQuery('#frequently-asked-questions-faq-mirrormate').length > 0 && sessionStorage.getItem('custFAQRedirect') !== null ) {
			setTimeout(function (){
				jQuery('html,body').animate({
					scrollTop: jQuery(".wrapper .content-container .faqsectiondiv:eq(1)").offset().top-200
				}); 
				
				if(jQuery(".wrapper .faqsectiondiv:eq(1) .faqpage #section1").hasClass('accordion-close')){
					jQuery(".wrapper .faqsectiondiv:eq(1) .faqpage #section1")[0].click();
				}
				sessionStorage.removeItem('custFAQRedirect');
			},1500);
		}
		
		function addCustHTMLForHpEducationFirst () {
			//change footer About us link
			if(jQuery('footer.site-footer ul li a:contains(About)').length > 0){
				jQuery('footer.site-footer ul li a:contains(About)').attr('href','https://www.mirrormate.com/pages/about-us');
			}
		
			//add custom HTML
			if (jQuery('.custMirrorMateHtmlSection').length == 0) {
				jQuery('<div class="custMirrorMateHtmlSection">'+window.MirrorMate012String1+window.MirrorMate012String2+'</div>').prependTo('.main-content');
			}
		
			//make the heading text in camel case 
			if(jQuery('.custom-content-container .custom__item .content h1').length > 0){
				var str =  jQuery('.custom-content-container .custom__item .content h1').text();
					str = str.toLowerCase().replace(/\b[a-z]/g, function(letter) {
					return letter.toUpperCase();
				});
				jQuery('.custom-content-container .custom__item .content h1').text(str);
			}
		
		
			jQuery('.custHowItWorksVideoPopup button#custPlayButton').trigger('click');
		
		
			if (jQuery('.shopify-section .custom-content .content .richtext .customBlueButton').length == 0) {
				jQuery('<a href="https://www.mirrormate.com/collections/all-frames" class="customBlueButton">SHOP POPULAR FRAMES</a>').appendTo('.shopify-section .custom-content .content .richtext');
			}
		
			//re-position the FQA at the last after the default section
			if(jQuery('.main-content .shopify-section:last').length > 0){
				jQuery('.custFAQBlock').insertAfter('.main-content .shopify-section:last');	
			}		
		
			if (jQuery('#custSlickSliderJS').length == 0) {
				jQuery("head").append('<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js" id="custSlickSliderJS"></script>');
			}
		
			if (jQuery('#custSlickSliderCSS').length == 0) {
				jQuery("head").append('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" id="custSlickSliderCSS" />');
			}
		
			//initialize sliders
			var intSlickCnt = 0;
			var intSlickInterval = setInterval(function() {
				intSlickCnt += 1;
				
				if (typeof jQuery().slick !== 'undefined') {
					
					var colorSlidesPerPage = 6,maxColorPages = 0,slidesPerPage = 5,maxPages = 0;
				   
					   //set the number of dots to show for slider
					jQuery(".custMostPopulerColorSlider").on("init", function(event, slick) {
						maxColorPages = Math.ceil(slick.slideCount / colorSlidesPerPage);
					});
		
					jQuery(".custMostPopulerColorSlider").slick({
						dots: true,
						infinite: true,
						arrows: true,
						slidesToShow: colorSlidesPerPage,
						slidesToScroll: 3,
						dotsClass: 'slick-dots',
						initialSlide: 0,
						responsive: [{
								breakpoint: 992,
								settings: {
									centerMode: true,
									centerPadding: '80px',
									slidesToShow: 3,
									initialSlide: 1,
									dots: false,
								}
							},
							{
								breakpoint: 768,
								settings: {
									centerMode: true,
									centerPadding: '30px',
									slidesToShow: 2,
									initialSlide: 1,
									dots: false,
								}
							}
						]
					});
		
					//set the number of dots to show for slider
					jQuery(".custClientReviewSlider").on("init", function(event, slick) {
						maxPages = Math.ceil(slick.slideCount / slidesPerPage);
					});
		
					jQuery(".custClientReviewSlider").slick({
						slidesToShow: slidesPerPage,
						slidesToScroll: slidesPerPage,
						autoplay: true,
						arrows: true,
						dots: true,
						infinite: true,
						dotsClass: 'slick-dots',
						responsive: [
							{
								breakpoint: 1200,
								settings: {
									dots: false,
									slidesToShow: 3,
									slidesToScroll: 3,
									centerMode: true,
									centerPadding: '80px',
								}
							},
							{
								breakpoint: 769,
								settings: {
									dots: false,
									slidesToShow: 2,
									slidesToScroll: 2,
									centerMode: true,
									centerPadding: '60px',
								}
								},
								{
								breakpoint: 641,
								settings: {
									dots: false,
									slidesToShow: 2,
									slidesToScroll: 2,
									centerMode: true,
									centerPadding: '30px',
								}
							}
						]
					});
		
					jQuery(".custMainVideoBlock").slick({
						slidesToShow: 3,
						infinite: true,
						slidesToScroll: 1,
						arrows: true,
						dots: true,
						responsive: [
							{
								breakpoint: 1200,
								settings: {
									centerPadding: '30px',
									slidesToShow: 3,
									dots: true,
								}
							},
							{
								breakpoint: 769,
								settings: {
									centerPadding: '20px',
									slidesToShow: 1
								}
							}
						]
					});
					
					clearInterval(intSlickInterval);
				}
		
				if (intSlickCnt === 80) {
					jQuery(".custMostPopulerColorSlider").show();
					clearInterval(intSlickInterval);
				}
			}, 50);
		}
		
		function updateTheHeadingStyle(){
			//make the heading text in camel case 
			var intCount    = 0;
			var intInterval = setInterval(function () {
				intCount   += 1;
		
				if(jQuery('.ssw-instagram-widget .gw-container h2').length > 0){
					flag = 1;
					var str =  jQuery('.ssw-instagram-widget .gw-container h2').text();
						str = str.toLowerCase().replace(/\b[a-z]/g, function(letter) {
						return letter.toUpperCase();
					});
					jQuery('.ssw-instagram-widget .gw-container h2').text(str);
				}
		
				if(intCount == 80){
					clearInterval(intInterval);
				}
			},50);
		}
		
		//on click of the FAQ open, close all other FQA accodion and open recent one
		 jQuery(document).on('click','.custFAQBlock input[type="checkbox"]',function(){
			 jQuery('.custFAQBlock input[type="checkbox"]').not(this).prop("checked", false);
		 });	
		
		 jQuery(window).scroll(function(){
			if(flag == 0){
				updateTheHeadingStyle();
			}
		});
		
		 //on click of the play CTA, play the video
		jQuery(document).on('click','.custHowItWorksVideoPopup button#custPlayButton',function(){
			 jQuery(this).hide();
			 var mediaVideo = jQuery("#custHowItWorkVideo").get(0);
			 mediaVideo.play();
		 });	
		
		//on click of the video CTA, pause the video
		 jQuery(document).on('click','.custHowItWorksVideoPopup #custHowItWorkVideo',function(){
			 var mediaVideo = jQuery("#custHowItWorkVideo").get(0);
			 mediaVideo.pause();
			 jQuery('.custHowItWorksVideoPopup button#custPlayButton').show();
		 });	
		
		 //on click of the Works On Any Mirror image redirect to FAQ
		 jQuery(document).on('click','.custWorksOnAnyMirror ul li a',function(){
			 sessionStorage.setItem('custFAQRedirect','1');
		 });	

		jQuery('body').css('opacity','1')
        clearInterval(waitForjQuery);
    }
}, 50); 