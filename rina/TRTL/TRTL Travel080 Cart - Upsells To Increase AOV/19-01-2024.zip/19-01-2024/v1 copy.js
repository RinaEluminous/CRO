console.log('TRTL Travel080: Cart - Upsells To Increase AOV');
 //change price position behind checkout 
var checkoutTextUpdated = false;
      if (!checkoutTextUpdated) {
          var newTextOfCheckout =  jQuery('a[href="/checkout"]').text() + ' - ' +jQuery('.col-6.mt-3.text-end').text();
          jQuery('a[href="/checkout"]').text(newTextOfCheckout);
          checkoutTextUpdated = true;
 }
  
var waitForJquery = setInterval(function() { 
    if (typeof jQuery != 'undefined') {

    addCustomUpSellProduct();
    addCustGetExtramsgMain();

    function addCustGetExtramsgMain(){
        var intGetExtramsgCnt = 0;
        var intGetExtramsgInterval = setInterval(function () {
              intGetExtramsgCnt += 1;
        var custGetExtramsgMainHtml ='<div class="custGetExtramsgMain">'+
                                    '    <p>You are <strong>$20</strong> away from getting an extra 10% off your order.</p>'+
                                    '    <div class="offerSlider">'+
                                    '        <div class="activeRangeSlider" style="width: 45%;"></div>'+
                                    '    </div>'+
                                    '    <div class="offerTooltipMain">'+
                                    '        <div class="insider">'+
                                    '            GET AN EXTRA 10% OFF'+
                                    '        </div>'+
                                    '    </div>'+
                                    '</div>';
            console.log('getextraMain length<<<<<<<<<<<<<<<<<<<<<<<<<<<',jQuery('.bm-t-023-active').length);

        if (jQuery('.bm-t-023-active').length > 0 && jQuery('.custGetExtramsgMain').length == 0){
            console.log('getextraMain >>>>>>>>>>>>>>')
            jQuery('.bm-t-023-active').nextAll('.col-12.my-0').first().after(custGetExtramsgMainHtml);
           
        }

        if(intGetExtramsgCnt === 50){
            clearInterval(intGetExtramsgInterval);
        }

        },70);
    }

    //wrap all features in one div

     // Check if the shipping-unlock-alert element exists
        if (jQuery('shipping-unlock-alert.bm-t-23-minicart-priorityText').length > 0 ) {
            // Select all col-12 elements that come after shipping-unlock-alert, excluding the first one
            var col12Elements = jQuery('shipping-unlock-alert.bm-t-23-minicart-priorityText').nextAll('.col-12:not(:first):lt(4)');
    
            // Wrap the selected col-12 elements in a new container
            if (col12Elements.length > 0) {
              
                col12Elements.wrapAll('<div class="custCartFeatures"></div>');
            }
        }

        //wrap price and item div into one div
       if (jQuery(".bm-t-23-showPriority").length > 0) {
        var col6Elements = jQuery(".bm-t-23-showPriority").nextAll('.col-6:lt(2)');

        if (col6Elements.length > 0) {
           
            col6Elements.wrapAll('<div class="custPriceItem"></div>');
        }
       }
        
    //to add custom HTML
	function addCustomUpSellProduct() {
            
        var custUpSellProductHtml = '<div class="custCartRecommendWraper">'+
        '    <h3>Recommended for you</h3>'+
        '    <ul class="recommendList">'+
        '        <li>'+
        '            <div class="itemContent">'+
        '                <div class="imgBox">'+
        '                    <img src="https://cdn.shopify.com/s/files/1/0071/0911/6022/products/TPO_GREY_LINDA_SLEEP_120x120_crop_center.jpg">'+
        '                </div>'+
        '                <div class="itemDetails">'+
        '                    <div class="title">TRAVEL PILLOW</div>'+
        '                    <div class="price">$44.99</div>'+
        '                </div>'+
        '                <div class="addBtn">Add</div>'+
        '                <div class="custProducts-colour-variant-swatches" id="custProducts-variant-swatches">'+
        '                    <a class="custCloseCrossBlocks">✕</a>'+
        '                    <div class="custSwitchBlocksSection">'+
        '                        <div class="custSwatchWrapper">'+
        '                            <div class="custSwatchColorPattern grey custSwatchActive" data-color="Grey" title="Grey"></div>'+
        '                            <div class="custSwatchColorPattern black" data-color="Black" title="Black"></div>'+
        '                            <div class="custSwatchColorPattern red" data-color="Red" title="Red"></div>'+
        '                            <div class="custSwatchColorPattern coral" data-color="Coral" title="Coral"></div>'+
        '                        </div>'+
        '                    </div>'+
        '                </div>'+
        '            </div>'+
        '        </li>'+
        '        <li>'+
        '            <div class="itemContent">'+
        '                <div class="imgBox">'+
        '                    <img src="https://cdn.shopify.com/s/files/1/0071/0911/6022/files/TRTLTravelPillowJunior-zebra-2_8e829f2f-477d-44fc-86f7-21e3152b6b4d_120x120_crop_center.jpg">'+
        '                </div>'+
        '                <div class="itemDetails">'+
        '                    <div class="title">PILLOW JUNIOR</div>'+
        '                    <div class="price">$35.99</div>'+
        '                </div>'+
        '                <div class="addBtn">Add</div>'+
        '                <div class="custProducts-colour-variant-swatches" id="custProducts-variant-swatches">'+
        '                    <a class="custCloseCrossBlocks">✕</a>'+
        '                    <div class="custSwitchBlocksSection">'+
        '                        <div class="custSwatchWrapper">'+
        '                            <div class="custSwatchColorPattern zebra custSwatchActive" data-color="Zebra" title="Zebra"></div>'+
        '                            <div class="custSwatchColorPattern aqua" data-color="Aqua" title="Aqua"></div>'+
        '                            <div class="custSwatchColorPattern camo" data-color="Camo" title="Camo"></div>'+
        '                        </div>'+
        '                    </div>'+
        '                </div>'+
        '            </div>'+
        '        </li>'+
        '        <li>'+
        '            <div class="itemContent">'+
        '                <div class="imgBox">'+
        '                    <img src="https://trtltravel.com/cdn/shop/products/IMG_9043cutcopy_1_5d863b0b-8659-4f15-8d08-6655256630e7_120x.jpg">'+
        '                </div>'+
        '                <div class="itemDetails">'+
        '                    <div class="title">COMPRESSION SOCKS</div>'+
        '                    <div class="price">$24.99</div>'+
        '                </div>'+
        '                <div class="addBtn">Add</div>'+
        '                <div class="custProducts-colour-variant-swatches" id="custProducts-variant-swatches">'+
        '                    <a class="custCloseCrossBlocks">✕</a>'+
        '                    <div class="custSwitchBlocksSection">'+
        '                        <div class="custSwatchWrapper">'+
        '                            <div class="custSwatchColorPattern new-york custSwatchActive" data-color="New-York" title="New York"></div>'+
        '                            <div class="custSwatchColorPattern fiji" data-color="Fiji" title="Fiji"></div>'+
        '                            <div class="custSwatchColorPattern kyoto" data-color="Kyoto" title="Kyoto"></div>'+
        '                            <div class="custSwatchColorPattern havana" data-color="Havana" title="Havana"></div>'+
        '                            <div class="custSwatchColorPattern paris" data-color="Paris" title="Paris"></div>'+
        '                            <div class="custSwatchColorPattern seattle" data-color="Seattle" title="Seattle"></div>'+
        '                            <div class="custSwatchColorPattern sydney" data-color="Sydney" title="Sydney"></div>'+
        '                            <div class="custSwatchColorPattern vancouver" data-color="Vancouver" title="Vancouver"></div>'+
        '                            <div class="custSwatchColorPattern jaipur" data-color="Jaipur" title="Jaipur"></div>'+
        '                        </div>'+
        '                        <div class="custSizeChart">'+
        '                            <div class="custRow">'+
        '                                <div class="cusColtSize">'+
        '                                    <div class="col-auto"><label class="btn btn-outline-dark px-4 custSizeChartActive" data-size="Small" for="template--15670323839169__main-2-0">Small</label></div>'+
        '                                    <div class="col-auto"><label class="btn btn-outline-dark px-4" data-size="Medium" for="template--15670323839169__main-2-1">Medium</label></div>'+
        '                                    <div class="col-auto"><label class="btn btn-outline-dark px-4" data-size="Large" for="template--15670323839169__main-2-2">Large</label></div>'+
        '                                </div>'+
        '                            </div>'+
        '                        </div>'+
        '                    </div>'+
        '                </div>'+
        '            </div>'+
        '        </li>'+
        '    </ul>'+
        '</div>';

        var intUpSellProductCnt = 0;
        var intUpSellProductInterval = setInterval(function () {
              intUpSellProductCnt += 1;

              console.log('custUpSellProductHtml length>>>>>>>>>>>>>>>>>>>>>>>>>>>',jQuery('a[href="/checkout"]').parent().length)

        if(jQuery('a[href="/checkout"]').parent().length > 0 && jQuery('.custCartRecommendWraper').length == 0) {
            console.log('custUpSellProductHtml >>>>>>>>>>>>>>>>>>>>>>>>>>>')
            jQuery('a[href="/checkout"]').parent().before(custUpSellProductHtml);

          
		}
        if(intUpSellProductCnt === 50){
            clearInterval(intUpSellProductInterval);
        }

        },70);
        
	}
     //on 'Add' CTA click of compression socks , show color/size panel
       jQuery(document).on('click','.custCartRecommendWraper .addBtn', function(){
        console.log('test');
        jQuery(this).find('.custProducts-colour-variant-swatches').addClass('custProductsOpen');
        
    }); 
 }
}, 50);   

